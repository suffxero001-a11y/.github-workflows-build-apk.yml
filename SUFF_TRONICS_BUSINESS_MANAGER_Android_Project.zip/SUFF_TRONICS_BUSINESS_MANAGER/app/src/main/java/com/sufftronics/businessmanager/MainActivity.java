package com.sufftronics.businessmanager;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.text.*;
import java.util.*;
import java.io.*;

public class MainActivity extends Activity {
    final int NAVY=Color.rgb(23,74,112), BLUE=Color.rgb(91,155,213), PALE=Color.rgb(221,235,247);
    final int GREEN=Color.rgb(112,173,71), ORANGE=Color.rgb(198,89,17), BG=Color.rgb(245,248,251);
    DB db; LinearLayout root, body, nav; String page="Dashboard";
    final SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
    final DecimalFormat money=new DecimalFormat("#,##0.00");
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); t.setPadding(12,8,12,8); return t; }
    String naira(double n){ return "₦"+money.format(n); }
    public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); show("Dashboard");}
    LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout horizontal(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); return l; }
    TextView button(String label,int color,Runnable run){ TextView t=text(label,14,Color.WHITE,true); t.setBackgroundColor(color); t.setGravity(Gravity.CENTER); t.setPadding(12,14,12,14); t.setOnClickListener(v->run.run()); return t; }
    void show(String p){
        page=p; root=vertical(); root.setBackgroundColor(BG); setContentView(root);
        TextView header=text("SUFF-TRONICS BUSINESS MANAGER",18,Color.WHITE,true); header.setGravity(Gravity.CENTER); header.setBackgroundColor(NAVY); header.setPadding(8,20,8,20); root.addView(header);
        TextView sub=text(p,17,NAVY,true); root.addView(sub);
        ScrollView sc=new ScrollView(this); body=vertical(); body.setPadding(12,4,12,20); sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=horizontal(); nav.setBackgroundColor(NAVY);
        String[] pages={"Dashboard","Income","Expenses","Reports","Backup"};
        for(String x:pages){ TextView n=text(x,12,Color.WHITE,x.equals(p)); n.setGravity(Gravity.CENTER); n.setPadding(5,16,5,16); n.setOnClickListener(v->show(x)); nav.addView(n,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav);
        if(p.equals("Dashboard")) dashboard(); else if(p.equals("Income")) entries("INCOME"); else if(p.equals("Expenses")) entries("EXPENSE"); else if(p.equals("Reports")) reports(); else backup();
    }
    void card(String title,String value,int color){
        LinearLayout c=vertical(); c.setBackgroundColor(PALE); TextView h=text(title,12,Color.WHITE,true); h.setGravity(Gravity.CENTER); h.setBackgroundColor(color);
        TextView v=text(value,19,NAVY,true); v.setGravity(Gravity.CENTER); c.addView(h); c.addView(v);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(4,6,4,6); body.addView(c,lp);
    }
    double total(String type,String from,String to,String product){
        String sql="SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type=? AND date>=? AND date<=?";
        ArrayList<String> args=new ArrayList<>(Arrays.asList(type,from,to));
        if(product!=null){sql+=" AND product=?";args.add(product);}
        Cursor c=db.getReadableDatabase().rawQuery(sql,args.toArray(new String[0])); c.moveToFirst(); double n=c.getDouble(0); c.close(); return n;
    }
    String today(){return df.format(new Date());}
    String startWeek(){Calendar c=Calendar.getInstance(); c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY); return df.format(c.getTime());}
    String endWeek(){Calendar c=Calendar.getInstance(); c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY); c.add(Calendar.DAY_OF_MONTH,6); return df.format(c.getTime());}
    String monthStart(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_MONTH,1);return df.format(c.getTime());}
    String monthEnd(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_MONTH,c.getActualMaximum(Calendar.DAY_OF_MONTH));return df.format(c.getTime());}
    String yearStart(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_YEAR,1);return df.format(c.getTime());}
    String yearEnd(){Calendar c=Calendar.getInstance();c.set(Calendar.MONTH,11);c.set(Calendar.DAY_OF_MONTH,31);return df.format(c.getTime());}
    void dashboard(){
        double di=total("INCOME",today(),today(),null), de=total("EXPENSE",today(),today(),null);
        double wi=total("INCOME",startWeek(),endWeek(),null), we=total("EXPENSE",startWeek(),endWeek(),null);
        double mi=total("INCOME",monthStart(),monthEnd(),null), me=total("EXPENSE",monthStart(),monthEnd(),null);
        double yi=total("INCOME",yearStart(),yearEnd(),null), ye=total("EXPENSE",yearStart(),yearEnd(),null);
        LinearLayout row=horizontal(); body.addView(row);
        addCard(row,"TODAY'S INCOME",naira(di),BLUE); addCard(row,"TODAY'S EXPENSE",naira(de),ORANGE);
        row=horizontal();body.addView(row);addCard(row,"TODAY'S PROFIT",naira(di-de),GREEN);addCard(row,"YEAR PROFIT",naira(yi-ye),NAVY);
        section("PERIOD SUMMARY");
        tableRow("Period","Income","Expenses","Profit",true);
        tableRow("Daily",naira(di),naira(de),naira(di-de),false);
        tableRow("Weekly",naira(wi),naira(we),naira(wi-we),false);
        tableRow("Monthly",naira(mi),naira(me),naira(mi-me),false);
        tableRow("Yearly",naira(yi),naira(ye),naira(yi-ye),false);
        section("RECENT TRANSACTIONS"); recent();
        body.addView(button("＋  Add Income",GREEN,()->show("Income")));
        body.addView(button("＋  Add Expense",ORANGE,()->show("Expenses")));
    }
    void addCard(LinearLayout row,String a,String b,int color){
        LinearLayout c=vertical(); c.setBackgroundColor(PALE);
        TextView h=text(a,11,Color.WHITE,true);h.setGravity(Gravity.CENTER);h.setBackgroundColor(color);
        TextView v=text(b,16,NAVY,true);v.setGravity(Gravity.CENTER);c.addView(h);c.addView(v);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(4,4,4,4);row.addView(c,lp);
    }
    void section(String s){TextView t=text(s,13,Color.WHITE,true);t.setBackgroundColor(NAVY);t.setGravity(Gravity.CENTER);body.addView(t);}
    void tableRow(String a,String b,String c,String d,boolean head){
        LinearLayout r=horizontal(); String[] vals={a,b,c,d};
        for(String s:vals){TextView t=text(s,10,head?Color.WHITE:NAVY,head);t.setGravity(Gravity.CENTER);if(head)t.setBackgroundColor(BLUE);r.addView(t,new LinearLayout.LayoutParams(0,-2,1));}
        body.addView(r);
    }
    void entries(String type){
        boolean inc=type.equals("INCOME");
        body.addView(button(inc?"＋  ADD INCOME":"＋  ADD EXPENSE",inc?GREEN:ORANGE,()->addDialog(type)));
        section(inc?"INCOME HISTORY":"EXPENSE HISTORY");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT date,product,amount FROM transactions WHERE type=? ORDER BY date DESC,id DESC",new String[]{type});
        while(c.moveToNext()){String d=c.getString(0),p=c.getString(1);double a=c.getDouble(2);
            LinearLayout item=horizontal();item.setBackgroundColor(Color.WHITE);
            TextView tx=text(d+"\n"+p,13,NAVY,true);item.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
            item.addView(text(naira(a),14,inc?GREEN:ORANGE,true));
            body.addView(item);
        } c.close();
        if(body.getChildCount()==1)body.addView(text("No records yet. Tap the button above to add your first entry.",14,NAVY,false));
    }
    void addDialog(String type){
        LinearLayout form=vertical(); EditText date=new EditText(this);date.setHint("Date (YYYY-MM-DD)");date.setText(today());
        EditText product=new EditText(this);product.setHint("Product name");
        EditText amount=new EditText(this);amount.setHint("Amount in Naira");amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(date);form.addView(product);form.addView(amount);
        new AlertDialog.Builder(this).setTitle(type.equals("INCOME")?"Record Income":"Record Expense").setView(form)
        .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            try{String dt=date.getText().toString().trim(),pr=product.getText().toString().trim();double am=Double.parseDouble(amount.getText().toString().trim());
                if(pr.isEmpty()||am<=0)throw new Exception();
                db.add(type,dt,pr,am);show(type.equals("INCOME")?"Income":"Expenses");
            }catch(Exception e){new AlertDialog.Builder(this).setMessage("Please enter a valid date, product and positive amount.").setPositiveButton("OK",null).show();}
        }).show();
    }
    void recent(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT date,product,amount,type FROM transactions ORDER BY date DESC,id DESC LIMIT 8",null);
        while(c.moveToNext())body.addView(text(c.getString(0)+"  •  "+c.getString(1)+"  •  "+naira(c.getDouble(2))+"  •  "+c.getString(3),12,NAVY,false));
        c.close();
    }
    void reports(){
        section("PRODUCT PERFORMANCE — YEAR TO DATE");
        productReport("INCOME"); productReport("EXPENSE");
        section("PERIOD TOTALS");
        tableRow("Period","Income","Expenses","Profit",true);
        String[][] ranges={{"Daily",today(),today()},{"Weekly",startWeek(),endWeek()},{"Monthly",monthStart(),monthEnd()},{"Yearly",yearStart(),yearEnd()}};
        for(String[] r:ranges){double i=total("INCOME",r[1],r[2],null),e=total("EXPENSE",r[1],r[2],null);tableRow(r[0],naira(i),naira(e),naira(i-e),false);}
    }
    void productReport(String type){
        body.addView(text(type.equals("INCOME")?"INCOME BY PRODUCT":"EXPENSE BY PRODUCT",13,type.equals("INCOME")?GREEN:ORANGE,true));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT DISTINCT product FROM transactions WHERE type=? ORDER BY product",new String[]{type});
        while(c.moveToNext()){
            String product=c.getString(0);
            double d=total(type,today(),today(),product);
            double w=total(type,startWeek(),endWeek(),product);
            double m=total(type,monthStart(),monthEnd(),product);
            double y=total(type,yearStart(),yearEnd(),product);
            body.addView(text(product+"\nDaily: "+naira(d)+"   Weekly: "+naira(w)+"\nMonthly: "+naira(m)+"   Yearly: "+naira(y),12,NAVY,false));
        }
        c.close();
    }
    void backup(){
        section("BACKUP & RESTORE");
        body.addView(text("Your records are stored locally on this phone. Export a CSV backup regularly and keep it somewhere safe.",14,NAVY,false));
        body.addView(button("EXPORT BACKUP (CSV)",BLUE,()->exportCsv()));
        body.addView(text("The exported file contains all income and expense entries and can be opened in Excel or Google Sheets.",12,GREY,false));
    }
    void exportCsv(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"suff_tronics_backup.csv");startActivityForResult(i,42);
    }
    protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==42&&res==RESULT_OK&&data!=null){
        try(OutputStream os=getContentResolver().openOutputStream(data.getData());Cursor c=db.getReadableDatabase().rawQuery("SELECT date,product,amount,type FROM transactions ORDER BY date",null)){
            os.write("Date,Product,Amount,Type\n".getBytes("UTF-8"));
            while(c.moveToNext()){String line=c.getString(0)+",\""+c.getString(1).replace("\"","")+"","+c.getDouble(2)+","+c.getString(3)+"\n";os.write(line.getBytes("UTF-8"));}
            c.close();Toast.makeText(this,"Backup exported successfully",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Backup failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }}
    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"suff_business.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,product TEXT NOT NULL,amount REAL NOT NULL,type TEXT NOT NULL)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void add(String type,String date,String product,double amount){ContentValues v=new ContentValues();v.put("type",type);v.put("date",date);v.put("product",product);v.put("amount",amount);getWritableDatabase().insert("transactions",null,v);}
    }
}
