# SUFF-TRONICS BUSINESS MANAGER

Offline-first native Android starter project.

## Included
- Dashboard with daily, weekly, monthly and annual income, expenses and profit.
- Separate income and expense entry screens.
- Product-based year-to-date reports.
- Local SQLite storage (no account or internet required).
- CSV backup export through Android's file picker.
- Navy/blue/green/orange visual theme.

## Build the APK
This environment does not include the Android SDK or Gradle, so it cannot compile/sign the APK here.
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create the APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager.

## Important
- Data is stored only on the phone. Uninstalling the app or clearing app data can erase local records.
- Use the Backup tab regularly to export CSV files.
- The current version provides CSV export. CSV import/restore, editing/deleting entries, date-range selection, and more advanced product-level daily/weekly/monthly/yearly drill-down can be added in a subsequent release.
